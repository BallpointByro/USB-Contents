extends Node

signal scoreChange

var speed: int = 350
var score: int = 0:
	set(value):
		score = value
		scoreChange.emit()

var crossPosition: Vector2
var circlePosition: Vector2
var squarePosition: Vector2
var trianglePosition: Vector2
var leftTriggerPosition: Vector2
var leftBumperPosition: Vector2
var rightTriggerPosition: Vector2
var rightBumperPosition: Vector2
var DPadDownPosition: Vector2
var DPadRightPosition: Vector2
var DPadLeftPosition: Vector2
var DPadUpPosition: Vector2