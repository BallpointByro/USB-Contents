extends Area2D

@export var target = "Cross"

var isInArea: bool = false

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	var targetList: Array = [
		"Cross",
		"Circle",
		"Square",
		"Triangle",
		"LeftTrigger",
		"LeftBumper",
		"RightTrigger",
		"RightBumper",
		"DPD",
		"DPR",
		"DPL",
		"DPU"
	]
	for i in range(len(


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if target == "Cross":
		position = position.move_toward(glo.crossPosition, glo.speed * delta)
	elif target == "Circle":
		position = position.move_toward(glo.circlePosition, glo.speed * delta)
	elif target == "Square":
		position = position.move_toward(glo.squarePosition, glo.speed * delta)
	elif target == "Triangle":
		position = position.move_toward(glo.trianglePosition, glo.speed * delta)
	elif target == "LeftTrigger":
		position = position.move_toward(glo.leftTriggerPosition, glo.speed * delta)
	elif target == "LeftBumper":
		position = position.move_toward(glo.leftBumperPosition, glo.speed * delta)
	elif target == "RightTrigger":
		position = position.move_toward(glo.rightTriggerPosition, glo.speed * delta)
	elif target == "RightBumper":
		position = position.move_toward(glo.rightBumperPosition, glo.speed * delta)
	elif target == "DPD":
		position = position.move_toward(glo.DPadDownPosition, glo.speed * delta)
	elif target == "DPR":
		position = position.move_toward(glo.DPadRightPosition, glo.speed * delta)
	elif target == "DPL":
		position = position.move_toward(glo.DPadLeftPosition, glo.speed * delta)
	elif target == "DPU":
		position = position.move_toward(glo.DPadUpPosition, glo.speed * delta)
		
	if target == "Right Stick":
		position.y += glo.speed * delta
	if isInArea and target == "Right Stick":
		glo.score += 1
		queue_free()
	
	if Input.is_action_just_pressed(target) and isInArea:
		print("Scene")
		glo.score += 1
		queue_free()

func _on_area_entered(area: Area2D):
	if area.name == target:
		isInArea = true
	if area.name == "fallKillzone":
		print("Zone")
		queue_free()

func _on_area_exited(area: Area2D):
	if area.name == target:
		isInArea = false
