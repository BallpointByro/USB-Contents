extends Area2D

@export var speed: int = 300

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	var direction = Input.get_axis("LSL", "LSR")
	if position.x <= 840:
		position.x += direction * speed * delta
	else:
		position.x = 839
	
	if position.x >= 300:
		position.x += direction * speed * delta
	else:
		position.x = 301
