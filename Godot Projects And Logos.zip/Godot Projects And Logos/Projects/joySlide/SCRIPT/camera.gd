extends Node2D

@export var dropDistance: float = 30.0
@export var returnDuration: float = 1.5

var cameraTween: Tween

func _ready() -> void:
	glo.scoreChange.connect(onScoreChange)

func onScoreChange(_newScore: int) -> void:
	print("A")
	position.y = 0
	if cameraTween:
		cameraTween.kill()
	
	cameraTween = create_tween()
	
	position.y += dropDistance
	
	cameraTween.tween_property(self, "position:y", position.y - dropDistance, returnDuration)\
		.set_trans(Tween.TRANS_QUAD)\
		.set_ease(Tween.EASE_OUT)
