extends Area2D

var isInArea: bool = false

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	glo.crossPosition = position


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func _on_area_entered(area: Area2D) -> void:
	isInArea = true

func _on_area_exited(area: Area2D) -> void:
	isInArea = false