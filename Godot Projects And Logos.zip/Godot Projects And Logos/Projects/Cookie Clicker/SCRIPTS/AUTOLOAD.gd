extends Node

var cookies: float
var cookiesPerSecond: float