extends Area2D

@onready var geo := $geo

@export var geoNoHoverSize: float = 3.0
@export var geoHoverSize: float = 3.5

@export var geoClickSize: float = 4.0


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func _on_mouse_entered() -> void:
	geo.scale = Vector2(geoHoverSize, geoHoverSize)
	
func _on_mouse_exited() -> void:
	geo.scale = Vector2(geoNoHoverSize, geoNoHoverSize)

func _on_input_event(viewport: Node, event: InputEvent, shape_idx: int) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		geo.scale = Vector2(geoClickSize, geoClickSize)
		
		aulo.cookies += 1
		
		get_viewport().set_input_as_handled()
	elif event is InputEventMouseButton and not event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		geo.scale = Vector2(geoHoverSize, geoHoverSize)
		get_viewport().set_input_as_handled()