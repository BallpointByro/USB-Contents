extends RigidBody2D

var is_dragging: bool = false

func _input_event(_viewport: Viewport, event: InputEvent, _shape_idx: int) -> void:
	# Detect left mouse click on the object
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			is_dragging = true
			freeze_mode = FREEZE_MODE_KINEMATIC
			freeze = true # Temporarily stop physics simulation

func _input(event: InputEvent) -> void:
	# Detect when the mouse button is released anywhere
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and not event.pressed:
		if is_dragging:
			is_dragging = false
			freeze = false # Turn physics back on

	# Move the object with the mouse if dragging
	if event is InputEventMouseMotion and is_dragging:
		global_position = get_global_mouse_position()
