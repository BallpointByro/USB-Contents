extends Node2D

@onready var cookieLabel := $"Cookie Amount Label"
@onready var cookiePerSecondLabel := $"Cookie Amount Per Second Label"

@onready var buildingScrollBar := $"Buildings and Upgrades/Building Scroll Bar"
@onready var toothpickBuilding := $"Buildings and Upgrades/Toothpick Building"
@onready var vacuumBuilding := $"Buildings and Upgrades/Vacuum Building"
@onready var microwaveBuilding := $"Buildings and Upgrades/Microwave Building"

@export var toothPickBeginY: float = 16.0
@export var vacuumBeginY: float = 160.0
@export var microwaveBeginY: float = 304.0

var toothpickPreload = preload("res://SCENES/Upgrade Effects/toothpick.tscn")
var toothpickTimerPreload = preload("res://SCENES/Upgrade Effects/background/toothPickTimer.tscn")

var vacuumPreload = preload("res://SCENES/Upgrade Effects/vacuum.tscn")
var vacuumTimerPreload = preload("res://SCENES/Upgrade Effects/background/VacuumTimer.tscn")

var microwavePreload = preload("res://SCENES/Upgrade Effects/microwave.tscn")
var microwaveTimerPreload = preload("res://SCENES/Upgrade Effects/background/microwaveTimer.tscn")

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	cookieLabel.text = str(int(aulo.cookies))
	cookiePerSecondLabel.text = str(aulo.cookiesPerSecond)
	
	toothpickBuilding.position.y = -(-toothPickBeginY + (buildingScrollBar.value * 5))
	vacuumBuilding.position.y = -(-vacuumBeginY + (buildingScrollBar.value * 5))
	microwaveBuilding.position.y = -(-microwaveBeginY + (buildingScrollBar.value * 5))


func _on_toothpick_building_pressed() -> void:
	if aulo.cookies >= 10:
		aulo.cookies -= 10
		aulo.cookiesPerSecond += 0.1
		
		var toothpick = toothpickPreload.instantiate()
		var toothpickTimer = toothpickTimerPreload.instantiate()
		get_tree().root.add_child(toothpick)
		get_tree().root.add_child(toothpickTimer)
		toothpick.position = Vector2(randi_range(333, 750), -50)


func _on_vacuum_building_pressed() -> void:
	if aulo.cookies >= 100:
		aulo.cookies -= 100
		aulo.cookiesPerSecond += 3
		
		var vacuum = vacuumPreload.instantiate()
		var vacuumTimer = vacuumTimerPreload.instantiate()
		get_tree().root.add_child(vacuum)
		get_tree().root.add_child(vacuumTimer)
		vacuum.position = Vector2(randi_range(333, 750), -50)

func _on_microwave_building_pressed() -> void:
	if aulo.cookies >= 750:
		aulo.cookies -= 750
		aulo.cookiesPerSecond += 11
		
		var microwave = microwavePreload.instantiate()
		var microwaveTimer = microwaveTimerPreload.instantiate()
		get_tree().root.add_child(microwave)
		get_tree().root.add_child(microwaveTimer)
		microwave.position = Vector2(randi_range(333, 750), -50)