extends Node2D

@onready var spinSection := $"Spin Section"
@onready var spinSection1Icon := $"Spin Section/1/Icon"

@export var numberOfOptions: int = 2 ## Multiples of 2
@export var listOfWeapons: Array = ["", ""]

var turnAngle: float
var currentSlot: int = 0

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	for i in range(numberOfOptions):
		pass # Set this to duplicate $1
	
	turnAngle = deg_to_rad(360.0 / numberOfOptions)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	spinSection1Icon.global_rotation = 0
	if Input.is_action_just_pressed("RotateL"):
		currentSlot -= 1
		animateRotation()
	elif Input.is_action_just_pressed("RotateR"):
		currentSlot += 1
		animateRotation()

func animateRotation() -> void:
	var targetRotation = currentSlot * turnAngle
	
	var tween = create_tween()
	
	tween.tween_property(spinSection, "rotation", targetRotation, 0.3)\
		.set_trans(Tween.TRANS_QUAD)\
		.set_ease(Tween.EASE_OUT)
