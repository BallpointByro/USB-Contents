extends CharacterBody3D

@onready var head := $Head

@export var speed := 5.0
@export var mouse_sensitivity := 0.003


var gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")

var isMouseHidden: bool = true

func _ready() -> void:
	# Captures the mouse cursor so it stays locked to the center of the game window
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _unhandled_input(event: InputEvent) -> void:
	# Handles turning the body left/right and tilting the head up/down
	if event is InputEventMouseMotion:
		rotate_y(-event.relative.x * mouse_sensitivity)
		head.rotate_x(-event.relative.y * mouse_sensitivity)
		head.rotation.x = clamp(head.rotation.x, deg_to_rad(-89), deg_to_rad(89))

func _physics_process(delta: float) -> void:
	# Apply regular downward gravity when not touching the ground
	if not is_on_floor():
		velocity.y -= gravity * delta

	# Get input direction using your custom case-sensitive binding names
	var input_dir := Input.get_vector("Move Left", "Move Right", "Move Forward", "Move Back")
	var direction := (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
	
	# Smoothly move or come to a stop
	if direction:
		velocity.x = direction.x * speed
		velocity.z = direction.z * speed
	else:
		velocity.x = move_toward(velocity.x, 0, speed)
		velocity.z = move_toward(velocity.z, 0, speed)

	if Input.is_action_just_pressed("Decouple Mouse"):
		if isMouseHidden:
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
			isMouseHidden = not isMouseHidden
		else:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
			isMouseHidden = not isMouseHidden

	move_and_slide()
