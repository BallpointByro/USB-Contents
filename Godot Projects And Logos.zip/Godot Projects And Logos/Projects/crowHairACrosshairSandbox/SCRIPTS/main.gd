extends CanvasLayer

@onready var importButton := $"Sandbox Panel/Import Button"
@onready var lineToolButton := $"Sandbox Panel/Tool Buttons/Line Tool Button"
@onready var freeToolButton := $"Sandbox Panel/Tool Buttons/Free Tool Button"
@onready var selectToolButton := $"Sandbox Panel/Tool Buttons/Select Tool Button"
@onready var lineToolLine := $"Sandbox Panel/Active Tool Lines/Line Tool Line"
@onready var freeToolLine := $"Sandbox Panel/Active Tool Lines/Free Tool Line"
@onready var selectToolLine := $"Sandbox Panel/Active Tool Lines/Select Tool Line"

@onready var RSlider := $"Sandbox Panel/RGB Selectors/R Slider"
@onready var RSliderTitleLabel := $"Sandbox Panel/RGB Selectors/R Slider/R Title Label"
@onready var RSliderValueLabel := $"Sandbox Panel/RGB Selectors/R Slider/R Value Label"
@onready var GSlider := $"Sandbox Panel/RGB Selectors/G Slider"
@onready var GSliderValueLabel := $"Sandbox Panel/RGB Selectors/G Slider/G Value Label"
@onready var GSliderTitleLabel := $"Sandbox Panel/RGB Selectors/G Slider/G Title Label"
@onready var BSlider := $"Sandbox Panel/RGB Selectors/B Slider"
@onready var BSliderTitleLabel := $"Sandbox Panel/RGB Selectors/B Slider/B Title Label"
@onready var BSliderValueLabel := $"Sandbox Panel/RGB Selectors/B Slider/B Value Label"
@onready var ASlider := $"Sandbox Panel/RGB Selectors/A Slider"
@onready var ASliderValueLabel := $"Sandbox Panel/RGB Selectors/A Slider/A Value Label"
@onready var ASliderTitleLabel := $"Sandbox Panel/RGB Selectors/A Slider/A Title Label"

@onready var swatchExample := $"Sandbox Panel/RGB Selectors/Swatch Example"

@onready var brushSizeSlider := $"Sandbox Panel/Brush Size Selector/Brush Size Slider"
@onready var brushSizeTitleLabel := $"Sandbox Panel/Brush Size Selector/Brush Size Title Label"
@onready var brushSizeValueLabel := $"Sandbox Panel/Brush Size Selector/Brush Size Value Label"

@onready var circleBrushTypeButton := $"Sandbox Panel/Brush Type Buttons/Button/Circle Button"
@onready var squareBrushTypeButton := $"Sandbox Panel/Brush Type Buttons/Button/Square Button"
@onready var circleBrushActiveLine := $"Sandbox Panel/Brush Type Buttons/Active Lines/Circle Line"
@onready var squareBrushActiveLine := $"Sandbox Panel/Brush Type Buttons/Active Lines/Square Button"

@onready var navigationPanelZoomValueLabel := $"Build Panel/Navigation Panel/Zoom Value"
@onready var navigationPanelPositionValueLabel := $"Build Panel/Navigation Panel/Position Value"

@export var zoomValue: int = 100
@export var zoomMax: int = 1000
@export var zoomMin: int = 10
@export var zoomPowerStep: int = 30
@export var zoomFineStep: int = 5
@export var zoomNormalStep: int = 15

var zoomStep: int = 30

var mousePosition: Vector2
var mousePositionBegin: Vector2
var mousePositionDifference: Vector2
var isDragging: bool = false

var position: Vector2

# L = Line
# F = Free
# S = Select
var activeSandboxTool: String = "L"
# S = Square
# C =  Circle
var activeLineType: String = "S"

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.

func setSliderLabels() -> void:
	RSliderValueLabel.text = str(int(RSlider.value))
	GSliderValueLabel.text = str(int(GSlider.value))
	BSliderValueLabel.text = str(int(BSlider.value))
	ASliderValueLabel.text = str(int(ASlider.value))
	
	brushSizeValueLabel.text = str(int(brushSizeSlider.value))

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	setSliderLabels()
	swatchExample.color = Color.from_rgba8(RSlider.value, GSlider.value, BSlider.value, ASlider.value)
	
	navigationPanelPositionValueLabel.text = str(int(mousePositionDifference.x), ", ", int(mousePositionDifference.y))
	
	mousePosition = get_viewport().get_mouse_position()
	
	if Input.is_action_just_pressed("Zoom In"):
		if zoomValue < zoomMax:
			zoomValue += zoomStep
		else:
			zoomValue = zoomMax
	elif Input.is_action_just_pressed("Zoom Out"):
		if zoomValue > zoomMin:
			zoomValue -= zoomStep
		else:
			zoomValue = zoomMin
	
	navigationPanelZoomValueLabel.text = str(zoomValue) + "%"
	
	# Handles tracking mouse movement difference while the action is held down
	if Input.is_action_just_pressed("Navigate"):
		isDragging = true
		mousePositionBegin = mousePosition
		mousePositionDifference = Vector2.ZERO
	
	if isDragging:
		mousePositionDifference = (mousePosition - mousePositionBegin)
		
	if Input.is_action_just_released("Navigate"):
		isDragging = false
	
	if Input.is_action_pressed("Power Move"):
		zoomStep = zoomPowerStep
	elif Input.is_action_pressed("Fine Move"):
		zoomStep = zoomFineStep
	else:
		zoomStep = zoomNormalStep


func swapActiveIndicator(active: String) -> void:
	if active == "L":
		lineToolLine.visible = true
		freeToolLine.visible = false
		selectToolLine.visible = false
	elif active == "F":
		lineToolLine.visible = false
		freeToolLine.visible = true
		selectToolLine.visible = false
	elif active == "S":
		lineToolLine.visible = false
		freeToolLine.visible = false
		selectToolLine.visible = true

func swapBrushActiveLines(active: String) -> void:
	if active == "C":
		circleBrushActiveLine.visible = true
		squareBrushActiveLine.visible = false
	elif active == "S":
		circleBrushActiveLine.visible = false
		squareBrushActiveLine.visible = true

func _on_line_tool_button_pressed() -> void:
	activeSandboxTool = "L"
	swapActiveIndicator(activeSandboxTool)


func _on_free_tool_button_pressed() -> void:
	activeSandboxTool = "F"
	swapActiveIndicator(activeSandboxTool)


func _on_select_tool_button_pressed() -> void:
	activeSandboxTool = "S"
	swapActiveIndicator(activeSandboxTool)


func _on_circle_button_pressed() -> void:
	activeLineType = "C"
	swapBrushActiveLines(activeLineType)


func _on_square_button_pressed() -> void:
	activeLineType = "S"
	swapBrushActiveLines(activeLineType)


func _on_zoom_in_pressed() -> void:
	zoomValue += zoomStep

func _on_zoom_out_pressed() -> void:
	zoomValue -= zoomStep
