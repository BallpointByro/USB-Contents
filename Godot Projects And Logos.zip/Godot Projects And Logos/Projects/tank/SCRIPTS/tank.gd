extends CharacterBody2D

@onready var treadGeo := $"Treads"
@onready var turretGeo := $"Turret"

const SPEED = 300.0
const AIMSPEED = 3.0
const TURNSPEED = 3.0

var bulletPreload := preload("res://SCENES/bullet.tscn")

func _physics_process(delta: float) -> void:
	var directionX := Input.get_axis("MoveLeft", "MoveRight")
	var directionY := Input.get_axis("MoveUp", "MoveDown")
	var directionRX := Input.get_axis("AimRight", "AimLeft")
	
	rotation += directionX * TURNSPEED * delta
	treadGeo.rotation = 0 
	
	if directionY:
		velocity = transform.x * -directionY * SPEED
		treadGeo.play("Drive")
	else:
		velocity = velocity.move_toward(Vector2.ZERO, SPEED)
		treadGeo.stop()

	turretGeo.rotation += -(deg_to_rad(directionRX * AIMSPEED))
	
	if Input.is_action_just_pressed("Fire"):
		var bullet = bulletPreload.instantiate()
		bullet.position = position
		add_child(bullet)

	move_and_slide()
 
