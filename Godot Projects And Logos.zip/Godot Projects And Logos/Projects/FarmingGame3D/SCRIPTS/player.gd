extends CharacterBody3D


var SPEED: float = 3.0

@onready var geo: AnimatedSprite3D = $AnimatedSprite3D

var canPlayerMove: bool = true

func _ready() -> void:
	UIGlobals.movePlayerCamera.connect(movePlayerCamera)
	UIGlobals.removePlayerCameraPosition.connect(resetPlayerCamera)

func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	var input_dir := Input.get_vector("MoveLeft", "MoveRight", "MoveUp", "MoveDown")
	var direction := (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
	if direction and canPlayerMove:
		velocity.x = direction.x * SPEED
		velocity.z = direction.z * SPEED
		
		geo.animation = "Walking"
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)
		velocity.z = move_toward(velocity.z, 0, SPEED)
		
		geo.animation = "Idle"
	
	if Input.is_action_pressed("Sprint"):
		SPEED = 4.0
	else:
		SPEED = 3.0
	
	if direction.x > 0.1: # greater than
		geo.flip_h = true
	elif direction.x < -0.1:
		geo.flip_h = false

	move_and_slide()

@warning_ignore("shadowed_variable_base_class")
func movePlayerCamera(position: Vector3):
	$Camera3D.global_position = position
	$Camera3D.rotation.x = deg_to_rad(-33.7)
	
	canPlayerMove = false

func resetPlayerCamera():
	$Camera3D.position = Vector3(0, 1.328, 2.986)
	$Camera3D.rotation.x = deg_to_rad(-10.1)
	
	canPlayerMove = true
