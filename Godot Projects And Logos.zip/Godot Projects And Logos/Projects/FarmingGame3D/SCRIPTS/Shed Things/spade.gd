extends Node3D

@onready var shovel: MeshInstance3D = $Shovel

var myArea: bool = false

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	shovel.rotation.y += .5 * delta
	
	if globals.isInInteractionZone and myArea and  Input.is_action_just_pressed("InteractUse"):
		UIGlobals.changeMode.emit("Harvest")


func _on_area_3d_body_entered(body: Node3D) -> void:
	UIGlobals.toolTipAppear.emit()
	UIGlobals.toolTipWrite.emit("E", "to equip Spade")
	
	globals.isInInteractionZone = true
	myArea = true


func _on_area_3d_body_exited(body: Node3D) -> void:
	UIGlobals.toolTipDisappear.emit()
	
	globals.isInInteractionZone = false
	myArea = false
