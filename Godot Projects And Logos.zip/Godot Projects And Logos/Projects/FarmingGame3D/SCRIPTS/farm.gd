extends Node3D

@onready var shed: Node3D = $Shed
@onready var farmAnimations: AnimationPlayer = $"Farm Animator"

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_shed_collision_area_body_entered(body: Node3D) -> void:
	farmAnimations.play("ShedOpenClose")


func _on_shed_collision_area_body_exited(body: Node3D) -> void:
	farmAnimations.play_backwards("ShedOpenClose")
