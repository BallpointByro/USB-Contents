extends Node

var canEnterMouseCaptured: bool = true

var currentMouseMode: String = "CAPTURED" # Can be "CAPTURED" or "VISIBLE"

func _ready() -> void:
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)

func _process(delta: float) -> void:
	if Input.is_action_just_pressed("ToggleMouse") and canEnterMouseCaptured:
		if currentMouseMode == "VISIBLE":
			currentMouseMode = "CAPTURED"
			Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
		else: # CAPTURED
			currentMouseMode = "VISIBLE"
			Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)

func forceMouseMode(type: String):
	if type == "VISIBLE":
		currentMouseMode = "CAPTURED"
		Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
	else: # CAPTURED
		currentMouseMode = "VISIBLE"
		Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
