extends Node

# CURRENT MODE
# If currentMode is "null": No mode is selected
# If currentMode is "farm" (string): Can farm/place crops
# If currentMode is "harvest (string): Can harvest plants
var currentMode = null

var isInInteractionZone = false
