extends Control


@onready var tooltipLabel: Label = $"Tooltip Label"
@onready var animationPlayer: AnimationPlayer = $AnimationPlayer

var actionCarriedOut: bool = false

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	UIGlobals.toolTipAppear.connect(showToolTip)
	UIGlobals.toolTipDisappear.connect(hideToolTip)
	UIGlobals.toolTipWrite.connect(changeToolTip)
	
	UIGlobals.changeMode.connect(changeMode)
	
	hideToolTip()

#region Tooltip Code
func changeToolTip(button: String, interaction: String):
	tooltipLabel.text = "'" + button + "' to " + interaction

func showToolTip():
	animationPlayer.play("TooltipMovement")


func hideToolTip():
	animationPlayer.play_backwards("TooltipMovement")
#endregion

func changeMode(mode: String):
	if mode == "Harvest":
		if globals.currentMode == "Harvest":
			animationPlayer.play_backwards("HarvestMode")
			globals.currentMode = null
		else:
			animationPlayer.play("HarvestMode")
			globals.currentMode = "Harvest"
	if mode == "Farm (c1)": # WORK HERE
		UIGlobals.movePlayerCamera.emit(Vector3(1.424, 3.164, 5.769))
		animationPlayer.play("PlantMode")
		MouseCapture.forceMouseMode("VISIBLE")


func _on_planting_back_button_pressed() -> void:
	MouseCapture.forceMouseMode("CAPTURED")
	
	animationPlayer.speed_scale = 2.0
	UIGlobals.removePlayerCameraPosition.emit()
	animationPlayer.play_backwards("PlantMode")
