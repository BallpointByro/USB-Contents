extends Node

@warning_ignore("unused_signal")
signal toolTipAppear
@warning_ignore("unused_signal")
signal toolTipDisappear
@warning_ignore("unused_signal")
signal toolTipWrite(button: String, interaction: String)
@warning_ignore("unused_signal")
signal changeMode(mode: String)

@warning_ignore("unused_signal")
signal movePlayerCamera(position: Vector3)
@warning_ignore("unused_signal")
signal removePlayerCameraPosition
