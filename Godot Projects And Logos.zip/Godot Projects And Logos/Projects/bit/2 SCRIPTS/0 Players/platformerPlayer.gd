extends CharacterBody2D

@onready var geo: AnimatedSprite2D = $geo

@onready var jumpSFX: AudioStreamPlayer = $"Jump SFX"
@onready var landSFX: AudioStreamPlayer = $"Land SFX"

const SPEED = 400.0
const JUMP_VELOCITY = -400.0

# right = true
# left = false
var currentDirection: bool = true

var isNotFloored: bool = true
var run: bool = true

func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Handle jump.
	if Input.is_action_pressed("PLATFORMER Jump") and is_on_floor():
		velocity.y = JUMP_VELOCITY
		jumpSFX.play()

	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	var direction := Input.get_axis("PLATFORMER Move Left", "PLATFORMER Move Right")
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)
		
	if direction == -1:
		currentDirection = false
		geo.play("Run")
	elif direction == 1:
		currentDirection = true
		geo.play("Run")
	elif direction == 0:
		geo.play("Idle")
		
	if currentDirection:
		geo.flip_h = false
	else:
		geo.flip_h = true
		
	if not is_on_floor():
		isNotFloored = false
	
	if is_on_floor() and isNotFloored == false:
		isNotFloored = true
		landSFX.play()

	move_and_slide()
