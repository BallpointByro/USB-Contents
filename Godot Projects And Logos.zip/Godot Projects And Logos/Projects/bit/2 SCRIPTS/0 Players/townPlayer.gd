extends CharacterBody2D

@onready var geo: AnimatedSprite2D = $geo

@export var SPEED: int = 300

# true = Facing Right
# false = Facing Left
var currentDirection: bool = true
var isMoving: bool = false

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if Input.is_action_pressed("TOWN Move Up"):
		position.y -= SPEED * delta
		isMoving = true
	if Input.is_action_pressed("TOWN Move Down"):
		position.y += SPEED * delta
		isMoving = true
	if Input.is_action_pressed("TOWN Move Left"):
		position.x -= SPEED * delta
		
		isMoving = true
		currentDirection = false
	if Input.is_action_pressed("TOWN Move Right"):
		position.x += SPEED * delta
		
		isMoving = true
		currentDirection = true
	
	if not (Input.is_action_pressed("TOWN Move Up") or Input.is_action_pressed("TOWN Move Down") or Input.is_action_pressed("TOWN Move Left") or Input.is_action_pressed("TOWN Move Right")):
		isMoving = false
	
	if isMoving == true:
		geo.play("Run")
	else:
		geo.play("Idle")
		
	if currentDirection == true:
		geo.flip_h = false
	else:
		geo.flip_h = true
