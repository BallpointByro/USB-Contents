extends Control

@onready var animationPlayer: AnimationPlayer = $AnimationPlayer
@onready var buttonPressedSFX: AudioStreamPlayer = $"Button Pressed"

var action: String = ""

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	pass

func _on_animation_wait_timer_timeout() -> void:
	animationPlayer.play("idle")


func _on_play_button_pressed() -> void:
	buttonPressedSFX.play()
	action = "play"

func _on_settings_button_pressed() -> void:
	buttonPressedSFX.play()
	action = "settings"

func _on_quit_button_pressed():
	buttonPressedSFX.play()
	action = "quit"

func _on_button_pressed_finished() -> void:
	if action == "play":
		get_tree().change_scene_to_file("res://1 SCENES/town.tscn")
	elif action == "settings":
		pass
	elif action == "quit":
		get_tree().quit()
