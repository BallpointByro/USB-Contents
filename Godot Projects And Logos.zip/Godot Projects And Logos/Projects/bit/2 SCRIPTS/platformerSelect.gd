extends Control

@onready var worldText: Label = $"World Label"

@onready var worldBackButton: Button = $"World Back Button"
@onready var worldForwardButton: Button = $"World Forward Button"

@onready var clickSFX: AudioStreamPlayer = $"Click SFX"

@export var currentWorld: int = 1

var action: String = ""

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
	
func changeWorldText() -> void:
	worldText.text = "World " + str(currentWorld)
	
func _on_world_forward_button_pressed() -> void:
	action = "Forward"
	if currentWorld != 8:
		currentWorld += 1
		changeWorldText()
	print("A")
	clickSFX.play()

func _on_world_back_button_pressed() -> void:
	action = "Back"
	if currentWorld != 1:
		currentWorld -= 1
		changeWorldText()
	print("B")
	clickSFX.play()

func _on_1_button_pressed() -> void:
	action = "1"
	clickSFX.play()

func _on_click_sfx_finished() -> void:
	print("Action: " + action)
	if action == "1":
		get_tree().change_scene_to_file("res://1 SCENES/1 Levels/0 World 1/0 Level 1.tscn")
	elif action == "2":
		pass
	elif action == "3":
		pass
	elif action == "4":
		pass
	elif action == "5":
		pass
	elif action == "6":
		pass
	elif action == "7":
		pass
	elif action == "8":
		pass
	else:
		print("Action Sent, but no action correlates to arguments. Presumed World Change buttons")
