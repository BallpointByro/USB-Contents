extends Node2D

signal levelEnd(level: int)

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func _on_level_victory_area_body_entered(body: Node2D):
	$VictorySFX.play()
	$"Wait Timer".start()

func _on_wait_timer_timeout():
	$animationPlayer.play("Fadeout")
	$"Wait Timer2".start()

func _on_wait_timer_2_timeout():
	get_tree().change_scene_to_file("res://1 SCENES/platformerSelect.tscn")
