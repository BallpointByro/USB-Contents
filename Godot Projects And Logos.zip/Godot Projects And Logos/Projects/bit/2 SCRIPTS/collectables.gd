extends Node2D

@onready var geo := $geo
@onready var pickupSFX: AudioStreamPlayer = $PickupSFX

@export_category("Collectable Type")
@export var wood: bool = false
@export var stone: bool = false
@export var metal: bool = false

var woodAtlasPosition: Vector2 = Vector2(0, 0)
var stoneAtlasPosition: Vector2 = Vector2(512, 0)
var metalAtlasPosition: Vector2 = Vector2(0, 512)
var ballAtlasPosition: Vector2 = Vector2(512, 512)

func setRegion(pos: Vector2) -> void:
	# Cast the duplicated resource so Godot knows it's an AtlasTexture
	var atlas := geo.texture.duplicate() as AtlasTexture
	atlas.region = Rect2(pos, Vector2(512, 512))
	geo.texture = atlas

func _ready() -> void:
	if wood:
		setRegion(woodAtlasPosition)
	elif stone:
		setRegion(stoneAtlasPosition)

func _process(delta: float) -> void:
	if metal and Globals.isInResolMode:
		setRegion(metalAtlasPosition)
	elif metal and not Globals.isInResolMode:
		setRegion(ballAtlasPosition)


func _on_area_2d_body_entered(body: Node2D) -> void:
	if wood:
		pickupSFX.play()
		Globals.woodAmount += randi_range(1, 3)
		queue_free()
	elif stone:
		pickupSFX.play()
		Globals.stoneAmount += randi_range(1, 3)
		queue_free()
	elif metal and Globals.isInResolMode:
		pickupSFX.play()
		Globals.metalAmount += 1
		queue_free()
