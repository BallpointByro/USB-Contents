extends Node2D

@onready var enterForestPanel: Panel = $UI/ForestPopup # may need to be a \ not /
@onready var buttonPressedSFX: AudioStreamPlayer = $UI/ButtonPressedSFX

var action: String = ""

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	enterForestPanel.visible = false
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	pass

func _on_platformer_entrance_body_entered(body: Node2D) -> void:
	enterForestPanel.visible = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _on_platformer_entrance_body_exited(body: Node2D) -> void:
	enterForestPanel.visible = false
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	
func _on_yes_pressed() -> void:
	action = "yes"
	buttonPressedSFX.play()

func _on_no_pressed() -> void:
	action = "no"
	buttonPressedSFX.play()


func _on_button_pressed_sfx_finished() -> void:
	if action == "no":
		enterForestPanel.visible = false
	elif action == "yes":
		get_tree().change_scene_to_file("res://1 SCENES/platformerSelect.tscn")
		
