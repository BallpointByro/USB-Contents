extends Node

var isInResolMode: bool = false

var woodAmount: int = 0
var stoneAmount: int = 0
var metalAmount: int = 0