extends CharacterBody2D

@onready var geo := $"geo"
@onready var chargeCast := $"Chargecast"
@onready var killCast := $"Killcast"
@onready var painCast := $"Paincast"

@export var walkSpeed: int = 300
@export var chargeSpeed: int = 700

var isCharging: bool = false

var health: int = 1 # 1: Normal, 2: Slightly Damaged, 3: Crispy, 4: Dead.

func _physics_process(delta: float) -> void:
	if !isCharging:
		velocity.x += walkSpeed * delta
	else: #isCharging is true
		velocity.x += chargeSpeed * delta
	
	move_and_slide()
