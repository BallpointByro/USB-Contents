extends Area2D

@onready var geo := $"geo"

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func _on_body_entered(body: Node2D) -> void: 
	glo.totalCoins += 1
	aud.playCoin()
	geo.play("Picked Up")

func _on_geo_animation_finished() -> void:
	queue_free()
