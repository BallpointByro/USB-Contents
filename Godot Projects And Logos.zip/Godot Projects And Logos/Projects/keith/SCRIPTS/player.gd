extends CharacterBody2D

@onready var geo := $"geo"
@onready var weaponCooldownTimer := $"Weapon Cooldown Timer"
@onready var hitbox := $"hitbox"

const SPEED = 100.0
const JUMP_VELOCITY = -300.0

var isInTest: bool = false

var isNotFire: bool = true
var isWeaponCooldown: bool = false

var bulletScene = preload("res://SCENES/bullet.tscn")

var dead: bool = false

func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor() and !dead:
		velocity += get_gravity() * delta
	
	velocity += glo.vel

	# Handle jump.
	if Input.is_action_just_pressed("Jump") and is_on_floor() and !dead:
		velocity.y = JUMP_VELOCITY
	if not is_on_floor() and isNotFire and !dead:
		geo.play("Jump")

	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	var direction := Input.get_axis("Left", "Right")
	if direction and not isInTest and !dead:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)
	
	if direction > 0 and !dead:
		geo.flip_h = false
		glo.direction = 1
	elif direction < 0 and !dead:
		geo.flip_h = true
		glo.direction = -1
	
	if direction and is_on_floor() and not isInTest and isNotFire and !dead:
		geo.play("Walk")
	if not direction and is_on_floor() and not isInTest and isNotFire and !dead:
		geo.play("Idle")

	# DEATH TEST
	if Input.is_action_just_pressed("TEST"):
		isInTest = true
		geo.play("Death")
	
	if Input.is_action_just_pressed("Fire") and not isWeaponCooldown and !dead:
		isNotFire = false
		isWeaponCooldown = true
		geo.play("Jump")
		
		var bullet = bulletScene.instantiate()
		bullet.global_position = global_position
		add_sibling(bullet)
		
		weaponCooldownTimer.start()
	elif Input.is_action_just_released("Fire"):
		isNotFire = true

	if glo.isPlayerDead and !dead:
		dead = true
		hitbox.disabled = true
		
		geo.position.y += 3
		geo.play("Death")
		
		await get_tree().create_timer(4).timeout
		glo.isPlayerDead = false
		get_tree().reload_current_scene()

	move_and_slide()


func _on_weapon_cooldown_timer_timeout() -> void:
	isWeaponCooldown = false
