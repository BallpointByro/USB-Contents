extends Node2D

@onready var coin: AudioStreamPlayer = $Coin

func playCoin() -> void:
	if coin:
		coin.play()
