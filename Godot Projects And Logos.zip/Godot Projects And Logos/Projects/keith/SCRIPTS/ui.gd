extends CanvasLayer

@onready var coinHundreds := $"Coins/Hundreds"
@onready var coinTens := $"Coins/Tens"
@onready var coinOnes := $"Coins/Ones"

var oneUnit: String
var tenUnit: String
var hunUnit: String

func _ready() -> void:
	pass


func _process(delta: float) -> void:
	var coinStr = str(glo.totalCoins).pad_zeros(3)
	
	hunUnit = coinStr[0]
	tenUnit = coinStr[1]
	oneUnit = coinStr[2]
	
	coinHundreds.frame = int(hunUnit)
	coinTens.frame = int(tenUnit)
	coinOnes.frame = int(oneUnit)
