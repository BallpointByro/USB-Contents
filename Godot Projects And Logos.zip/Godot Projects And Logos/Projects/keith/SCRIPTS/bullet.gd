extends Area2D

@export var speed: float = 200.0

var direction: int = 0

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	direction = glo.direction


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:

	position.x += (speed * direction) * delta
