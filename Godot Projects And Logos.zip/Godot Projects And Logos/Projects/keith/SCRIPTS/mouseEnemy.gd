extends CharacterBody2D

@onready var geo := $"geo"
@onready var hitbox := $"CollisionShape2D"

@onready var raycastL := $"Raycast Left"
@onready var raycastR := $"Raycast Right"
@onready var raycastKS := $"Raycast Kill Self"
@onready var raycastKR := $"Raycast Kill Player Right"
@onready var raycastKL := $"Raycast Kill Player Left"

@export var speed: int = 60

var direction: bool = true

func _physics_process(delta: float) -> void:
	if direction:
		geo.flip_h = false
		global_position.x -= speed * delta
	else:
		geo.flip_h = true
		global_position.x += speed * delta
		
	if raycastL.is_colliding():
		direction = false
	elif raycastR.is_colliding():
		direction = true
	
	if raycastKS.is_colliding():
		speed = 0
		hitbox.disabled = true
		
		raycastKS.enabled = false
		raycastL.enabled = false
		raycastR.enabled = false
		raycastKR.enabled = false
		raycastKL.enabled = false
		
		glo.vel.y = -30
		glo.totalCoins += 1
		
		geo.play("Death")
		await get_tree().create_timer(0.1).timeout
		glo.vel.y = 0
		await get_tree().create_timer(2.0).timeout
		queue_free()
		
	if raycastKL.is_colliding() or raycastKR.is_colliding():
		glo.isPlayerDead = true

	move_and_slide()
