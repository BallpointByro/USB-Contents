extends Node

var totalCoins: int = 0
var direction: int = 1
var vel: Vector2 = Vector2(0, 0)

var isPlayerDead: bool = false
