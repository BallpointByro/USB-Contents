extends Node

var xp: int = 0
var level: int = 1

var coins: int = 0

var isLevelUp: bool = false # Level up screen showing?

var playerHealth: int = 100
var playerPosition: Vector2
var playerDirection: bool = true # Right
var isDead: bool = false

var isWeaponOpen: bool = false

var wave: int = 1

var powerupSpawnPosition: Vector2

# Given sword is used at start, it is already on level 1, all rest on 0
# Reference Level Up Name: powerupDictionary.keys()[0]
# Reference Level Up Text: powerupDictionary["Sword"][0][(powerUpDictionary["Sword"][1])+1]
# Reference Level Integer: powerupDictionary["Sword"][1]
# Reference Damage Integer: powerupDictionary["Sword"][2]
# Replace "Sword" with desired powerup/buff name
var powerupDictionary: Dictionary = {
	"Sword": [
		{
			0: "A weapon that swings in a horizontal swooping motion. 10-20 Damage",
			1: "Deals +8-14 Damage",
			2: "One extra swoop in the opposite direction",
			3: "Less cooldown (3s -> 1s)",
			4: "Deals +9-15 Damage",
			5: "Double Damage. Swings 1s -> 0.5s \n MAX LEVEL"
		},
		1,
		randi_range(10, 20)
	],
	"Mace": [
		{
			0: "Throws up and falls down in an arc. 12-18 Damage",
			1: "Throws with a larger arc",
			2: "Deals +4-10 Damage",
			3: "Less cooldown (5s -> 2.5s)",
			4: "Double size",
			5: "Deals +8-15 Damage",
		},
		0
	],
	"Banana": [
		{
			0: "Heals 0.1 HP every 2 seconds",
			1: "Heals +0.2 HP",
			2: "Heals +0.4 HP",
			3: "Heals +0.2 HP",
			4: "Heals +0.1 HP",
			5: "Cooldown 2s -> 0.7s",
		},
		0
	]
}

func _process(delta: float) -> void:
	if xp >= 100:
		isLevelUp = true
		xp = 0
		level += 1