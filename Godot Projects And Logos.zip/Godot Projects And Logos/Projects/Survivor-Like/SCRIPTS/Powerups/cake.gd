extends Area2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	global_position = Globals.powerupSpawnPosition


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func _on_body_entered(body: Node2D) -> void:
	if body.name == "Player":
		if Globals.playerHealth <= 70:
			Globals.playerHealth += 30
		else:
			Globals.playerHealth += (100 - Globals.playerHealth)
		$AudioStreamPlayer.play()

func _on_audio_stream_player_finished() -> void:
	queue_free()
