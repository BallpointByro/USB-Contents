extends Area2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	position = Globals.powerupSpawnPosition


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func _on_body_entered(body: Node2D) -> void:
	if body.name == "Player":
		Globals.coins += 10
		$AudioStreamPlayer.play()
		
func _on_audio_stream_player_finished() -> void:
	queue_free()