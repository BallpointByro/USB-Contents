extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	$geo.visible = false


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if Globals.playerDirection == false:
		scale.x = -1
	elif Globals.playerDirection == true:
		scale.x = 1

func _on_cooldown_timeout() -> void:
	$Killzone.monitorable = true
	$geo.visible = true
	Globals.isWeaponOpen = true
	$Active.start()

func _on_active_timeout() -> void:
	$geo.visible = false
	$Killzone.monitorable = false
	Globals.isWeaponOpen = false
	
func _on_killzone_body_entered(body: Node2D) -> void:
	pass