extends CharacterBody2D

const SPEED: int = 75

# Get a reference to your Sprite2D node to handle flipping
# Change "Sprite2D" to the exact name of your sprite node if it is different
@onready var geo: AnimatedSprite2D = $geo

var manaOrb = preload("res://SCENES/manaOrb.tscn")

var health: int = 1
var damage: int = 10

func _ready() -> void:
	position = Vector2(randi_range(-3000, 3000), randi_range(-3000, 3000))

func _physics_process(delta: float) -> void:
	var target_position: Vector2 = Globals.playerPosition
	var direction: Vector2 = global_position.direction_to(target_position)
	
	if global_position.distance_to(target_position) > 10.0:
		# Move the velocity vector toward our target movement vector
		velocity = velocity.move_toward(direction * SPEED, SPEED * 10 * delta)
	else:
		# Stop smoothly when close enough
		velocity = velocity.move_toward(Vector2.ZERO, SPEED * 10 * delta)
	
	if direction.x > 0:
		geo.flip_h = false # Facing Right
	elif direction.x < 0:
		geo.flip_h = true  # Facing Left
		
	move_and_slide()

func _on_kill_area_area_entered(area: Area2D) -> void:
	if area.name == "Killzone" and health > 0:
		health -= Globals.powerUpDictionary["Sword"][2]
	elif area.name == "Killzone" and health <= 0:
		var manaOrbI = manaOrb.instantiate()
		get_tree().root.add_child(manaOrbI)
		manaOrbI.global_position = global_position
		queue_free()

func _on_damage_area_body_entered(body: Node2D) -> void:
	if body.name == "Player":
		Globals.playerHealth -= damage
