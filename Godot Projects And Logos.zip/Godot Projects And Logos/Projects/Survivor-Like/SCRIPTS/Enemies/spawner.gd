extends Node2D

@export var minWait: float = 0.0
@export var maxWait: float = 0.5

var slug1P = preload("res://SCENES/Enemies/slug1.tscn")


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func _on_timer_timeout() -> void:
	$"Random Timer".wait_time = randf_range(minWait, maxWait)
	$"Random Timer".start()

func _on_random_timer_timeout() -> void:
	if Globals.wave >= 1 and Globals.wave <= 5:
		var slug1I = slug1P.instantiate()
		get_tree().root.add_child(slug1I)
