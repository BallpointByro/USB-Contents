extends Node2D

var cakeP = preload("res://SCENES/cake.tscn")
var coinP = preload("res://SCENES/coin.tscn")
var coinBagP = preload("res://SCENES/coinBag.tscn")

var dropList: Array = [cakeP, coinP, coinBagP]

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	# randi_range(-3000, 3000), randi_range(-3000, 3000)
	position = Vector2(randi_range(-100, 100), randi_range(-100, 100))


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func _on_clear_zone_area_entered(area: Area2D) -> void:
	Globals.powerupSpawnPosition = global_position
	var instatiatedDrop = dropList.pick_random().instantiate()
	get_tree().root.add_child(instatiatedDrop)
	queue_free()
