extends CharacterBody2D
class_name Player

@export var speed: float = 300.0

func _ready() -> void:
	$DeathScreen/DeathScreen.visible = false

func _physics_process(delta: float) -> void:
	var inputPower := Vector2(Input.get_action_strength("ui_right") - Input.get_action_strength("ui_left"), Input.get_action_strength("ui_down") - Input.get_action_strength("ui_up"))

	inputPower = inputPower.normalized()

	velocity = inputPower * speed
	
	if velocity and Globals.playerHealth > 0:
		$geo.play("Walk")
	elif not velocity and Globals.playerHealth > 0:
		$geo.play("Idle")
	
	if Input.is_action_just_pressed("ui_left"):
		Globals.playerDirection = false
		$geo.flip_h = true
	elif Input.is_action_just_pressed("ui_right"):
		Globals.playerDirection = true
		$geo.flip_h = false
	
	Globals.playerPosition = position
	
	$Healthbar.value = Globals.playerHealth
	
	if Globals.playerHealth <= 0 and Globals.isDead == false:
		inputPower = Vector2(0, 0)
		Globals.isDead = true
		$geo.play("Death")
		$Death.play()
		await get_tree().create_timer(2.5).timeout
		$DeathScreen/DeathScreen.visible = true
	
	move_and_slide()

func _on_button_pressed() -> void:
	get_tree().change_scene_to_file("res://SCENES/mainScreen.tscn")
