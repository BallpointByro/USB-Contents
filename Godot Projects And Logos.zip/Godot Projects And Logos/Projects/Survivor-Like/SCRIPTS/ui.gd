extends CanvasLayer

var texturePathsArray: Array = ["res://ASSETS/UI/Icons/Banana.png", "res://ASSETS/UI/Icons/Mace.png", "res://ASSETS/UI/Icons/Sword.png"]

@onready var selection1: Sprite2D = $"Level Up/Selection 1"
@onready var selection1Button: Button = $"Level Up/Selection 1/Activate Button"
@onready var selection1TitleLabel: Label = $"Level Up/Selection 1/Title Label"
@onready var selection1DescriptionLabel: Label = $"Level Up/Selection 1/Description Label"
@onready var selection1LevelLabel: Label = $"Level Up/Selection 1/Level Label"

@onready var selection2: Sprite2D = $"Level Up/Selection 2"
@onready var selection2Button: Button = $"Level Up/Selection 2/Activate Button"
@onready var selection2TitleLabel: Label = $"Level Up/Selection 2/Title Label"
@onready var selection2DescriptionLabel: Label = $"Level Up/Selection 2/Description Label"
@onready var selection2LevelLabel: Label = $"Level Up/Selection 2/Level Label"


@onready var selection3: Sprite2D = $"Level Up/Selection 3"
@onready var selection3Button: Button = $"Level Up/Selection 3/Activate Button"
@onready var selection3TitleLabel: Label = $"Level Up/Selection 3/Title Label"
@onready var selection3DescriptionLabel: Label = $"Level Up/Selection 3/Description Label"
@onready var selection3LevelLabel: Label = $"Level Up/Selection 3/Level Label"


var timeAlive: float = 0.0

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	#$"Level Up".visible = false
	showLevelUps() # Test - delete when done


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	$ProgressLabel.text = str($ProgressBar.value) + "%"
	$ProgressBar.value = Globals.xp
	$LevelLabel.text = "lvl " + str(Globals.level)
	
	timeAlive += delta
	
	$TimeLabel.text = str("%.1f" % timeAlive)

	$CoinLabel.text = str(Globals.coins)
	
func showLevelUps() -> void:
	var powerupArray: Array = []
	for i in range(3):
		powerupArray.append(Globals.powerupDictionary.keys().pick_random())
	
	selection1TitleLabel.text = powerupArray[0]
	print(powerupArray[0])
	selection2TitleLabel.text = powerupArray[1]
	print(powerupArray[1])
	selection3TitleLabel.text = powerupArray[2]
	print(powerupArray[2])
	
	selection1DescriptionLabel.text = Globals.powerupDictionary[str(powerupArray[0])][0][(Globals.powerupDictionary[str(powerupArray[0])][1])]
	print(Globals.powerupDictionary[str(powerupArray[0])][0][(Globals.powerupDictionary[str(powerupArray[0])][1])])
	selection2DescriptionLabel.text = Globals.powerupDictionary[str(powerupArray[1])][0][(Globals.powerupDictionary[str(powerupArray[1])][1])]
	print(Globals.powerupDictionary[str(powerupArray[1])][0][(Globals.powerupDictionary[str(powerupArray[1])][1])])
	selection3DescriptionLabel.text = Globals.powerupDictionary[str(powerupArray[2])][0][(Globals.powerupDictionary[str(powerupArray[2])][1])]
	print(Globals.powerupDictionary[str(powerupArray[2])][0][(Globals.powerupDictionary[str(powerupArray[2])][1])])
	
	selection1LevelLabel.text = Globals.powerupDictionary[str(powerupArray[0])][1]
