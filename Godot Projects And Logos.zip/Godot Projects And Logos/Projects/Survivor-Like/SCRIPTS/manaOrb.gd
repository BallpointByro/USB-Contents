extends Area2D

@export var active: bool = true ## When FALSE, pickup doesn't work.

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func _on_body_entered(body: Node2D):
	if active and body.name == "Player":
		Globals.xp += round(10 / Globals.level)
		queue_free()
